# ShopEasy - Online Shopping Cart

A simple, ready-to-run online shopping cart built with **HTML, CSS, and vanilla JavaScript**.

## Features

- Product listing
- Add products to cart
- Increase/decrease quantities
- Remove products
- Clear cart
- Automatic subtotal, 8% tax, and total calculation
- Cart item count
- Persistent cart using `localStorage`
- Responsive design
- Checkout modal
- Checkout form validation
- Demo order confirmation
- No backend or database required

## Project Structure

```text
online-shopping-cart/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
├── .gitignore
└── README.md
```

## Run in VS Code

### Option 1: Live Server

1. Open this folder in VS Code.
2. Install the **Live Server** extension if you do not already have it.
3. Right-click `index.html`.
4. Select **Open with Live Server**.

### Option 2: Directly open

You can also open `index.html` directly in a browser. No build step is required.

## Git Commands

If you want to create your own Git repository:

```bash
git init
git add .
git commit -m "Initial online shopping cart"
```

Then create an empty repository on GitHub and connect it:

```bash
git remote add origin https://github.com/YOUR_USERNAME/online-shopping-cart.git
git branch -M main
git push -u origin main
```

## Notes

This is a frontend demo. The checkout validates customer details but does not connect to a real payment provider or backend.

To make this production-ready, add a backend API, database, authentication, inventory management, secure server-side price validation, and a payment provider such as Stripe.
